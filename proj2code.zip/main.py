# Appendix
# Python Code

# Project 2

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import time
import copy


print('UBitName = amirbagh')
print('personNumber = 50135018')

syn_input_data = pd.read_csv('input.csv',header=None).values
syn_output_data = pd.read_csv('output.csv',header=None).values
letor_input_data = pd.read_csv('Querylevelnorm_X.csv',header=None).values
letor_output_data = pd.read_csv('Querylevelnorm_t.csv',header=None).values

# LeToR or synthetic Data?
data_choose_in = letor_input_data
data_choose_out = letor_output_data
#data_choose_in = syn_input_data
#data_choose_out = syn_output_data

# define hyper-parameters 

num_epochs = 100
# 3 for syn and 6 for LeTor
cluster_numbers = 6
# 0.4 for syn and 0.5 for LeToR
learning_rate = 0.5
L2_lambda = 1e-4


def Kmeans_clustring(k, data):
    n_clusters = k
    n_features = np.shape(data)[1]
    X_cluster = data
    kmeans = KMeans(n_clusters=n_clusters, random_state=0).fit(X_cluster)
    labels = kmeans.labels_
    #print(kmeans.predict([[0, 0], [4, 4]]))
    cluster_centroids = kmeans.cluster_centers_
    cluster_spreads = np.empty((n_clusters,n_features,n_features))
    for i in range(k):
        cluster_spreads[i,:,:] = np.cov(X_cluster[np.where(i == kmeans.labels_)[0],:].T)
     
    return (k, cluster_centroids, cluster_spreads)

def dataset_partition(train_percent, val_percent, test_percent, data, indexes):
    data_lngth = np.shape(data)[0]
    train_data = data[indexes[0:round(train_percent * data_lngth)],:]
    val_data = data[indexes[round(train_percent * data_lngth):round((train_percent + val_percent) * data_lngth)],:]
    test_data = data[indexes[round((train_percent + val_percent) * data_lngth):data_lngth],:]
    return (train_data, val_data, test_data)

def compute_design_matrix(input_data, clusters_data):
    # Design matrix 
    N, D = input_data.shape
    # shape = [M, 1, D]
    #centers = np.array([np.ones((D))*1, np.ones((D))*0.5, np.ones((D))*1.5])
    centers = clusters_data[1]
    centers = centers[:, np.newaxis, :]
    # shape = [M, D, D]
    #spreads = np.array([np.identity(D), np.identity(D), np.identity(D)]) * 0.5
    spreads = clusters_data[2]
    # shape = [1, N, D]
    X = input_data[np.newaxis, :, :]
    
    # use broadcast
    basis_func_outputs = np.exp(
        np.sum(
            np.matmul(X - centers, spreads) * (X - centers),
            axis=2
        ) / (-2)
    ).T
    # insert ones to the 1st col
    
    return np.insert(basis_func_outputs, 0, 1, axis=1)

def closed_form_sol(L2_lambda, design_matrix, output_data_train):
    return np.linalg.solve(
        L2_lambda * np.identity(design_matrix.shape[1]) +
            np.matmul(design_matrix.T, design_matrix),
        np.matmul(design_matrix.T, output_data_train)
    ).flatten()

def SGD_sol(learning_rate,
            minibatch_size,
            num_epochs,
            L2_lambda,
            design_matrix_train,
            design_matrix_eval,
            output_data_train,
            output_data_eval,
            M):
    N, _ = design_matrix_train.shape
    # You can try different mini-batch size size
    # Using minibatch_size = N is equivalent to standard gradient descent
    # Using minibatch_size = 1 is equivalent to stochastic gradient descent
    # In this case, minibatch_size = N is better
    # The more epochs the higher training accuracy. When set to 1000000,
    # weights will be very close to closed_form_weights. But this is unnecessary
    weights = np.zeros([1, M+1])
    train_loss = []
    eval_loss = []
    train_err = []
    eval_err = []
    params = np.empty((num_epochs,1,M+1))
    for epoch in range(num_epochs):
        for i in range(N // minibatch_size):
            lower_bound = i * minibatch_size
            upper_bound = min((i+1)*minibatch_size, N)
            
            Err_SGD = err_func(Phi = design_matrix_train[lower_bound : upper_bound, :], 
                               weights = weights, 
                               t = output_data_train[lower_bound : upper_bound, :], 
                               L2_lambda = L2_lambda, 
                               minibatch_size = minibatch_size)
            weights = weights - learning_rate * Err_SGD[3]

            Err_train = err_func(Phi = design_matrix_train[lower_bound : upper_bound, :], 
                                 weights = weights, 
                                 t = output_data_train[lower_bound : upper_bound, :], 
                                 L2_lambda = L2_lambda, 
                                 minibatch_size = minibatch_size)

            Err_eval = err_func(Phi = design_matrix_eval[lower_bound : upper_bound, :], 
                                weights = weights, 
                                t = output_data_eval[lower_bound : upper_bound, :], 
                                L2_lambda = L2_lambda, 
                                minibatch_size = minibatch_size)
            
            train_E = errorFrom(designMatrix=design_matrix_train,weights=weights.flatten(),targets=output_data_train)
            
            eval_E = errorFrom(designMatrix=design_matrix_eval,weights=weights.flatten(),targets=output_data_eval)
        
        params[epoch,:,:] = weights
        train_loss = np.append(train_loss, Err_train[1])
        eval_loss = np.append(eval_loss, Err_eval[1])
        train_err = np.append(train_err, train_E)
        eval_err = np.append(eval_err, eval_E)

    return (params, train_loss, eval_loss, train_err, eval_err)

def err_func(Phi, 
             weights, 
             t, 
             L2_lambda, 
             minibatch_size):

    E_D_p = np.sum(np.power(np.matmul(Phi, weights.T)-t, 2)
                            )
    E_D = (E_D_p + L2_lambda * np.matmul(weights, weights.T)) / (2*minibatch_size)
    E_RMS = np.sqrt(2*E_D)
    #print('E_D =',E_D)
    d_E_p = np.matmul(
            (np.matmul(Phi, weights.T)-t).T,
                      Phi
                     )
    d_E = (d_E_p + L2_lambda * weights) / minibatch_size
    d_E_norm = np.linalg.norm(d_E)
    #print('d_E =',d_E_norm)
    
    return(E_D, E_RMS, d_E_p, d_E, d_E_norm)


def errorFrom(designMatrix, weights, targets):
    predicted_target = np.dot(designMatrix, weights)
    diff = predicted_target - targets[:,0]
    error = np.sqrt((np.dot(diff.T, diff).item())/diff.shape[0])  
    return error

def earlyStopping(max_epochs, patience, n_epochs, params, this_validation_loss):
    # early-stopping parameters
    p = patience  # look as this many examples regardless
    theta = np.random.rand(1,4)
    i = 0
    j = 0
    v = np.inf
    theta_s = theta
    i_s = i
    done_looping = False
    while (j < p) and (not done_looping):
        theta = params[i,:,:]  
        v_p = this_validation_loss[i]
        i = i + n_epochs
        if v_p < v:
            j = 0
            theta_s = theta
            i_s = i
            v = v_p
        else:
            j = j + 1
        
        if i >= max_epochs:
            done_looping = True
            break
        
    return (theta_s, i_s)


# data partition and preprocessing

# shuffling the data
data_index = list(range(0, np.shape(data_choose_in)[0]))
np.random.shuffle(data_index)

data_partition_in = dataset_partition(train_percent=0.8, val_percent=0.1, test_percent=0.1, data=data_choose_in, indexes=data_index)
data_partition_out = dataset_partition(train_percent=0.8, val_percent=0.1, test_percent=0.1, data=data_choose_out, indexes=data_index)

input_data_train = data_partition_in[0]
output_data_train = data_partition_out[0]

input_data_eval = data_partition_in[1]
output_data_eval = data_partition_out[1]

input_data_test = data_partition_in[2]
output_data_test = data_partition_out[2]

clusters_info = Kmeans_clustring(k=cluster_numbers, data=input_data_train)

design_matrix_train = compute_design_matrix(input_data_train, clusters_info)
design_matrix_eval = compute_design_matrix(input_data_eval, clusters_info)
design_matrix_test = compute_design_matrix(input_data_test, clusters_info)

# Closed-form solution
w_closed = closed_form_sol(L2_lambda=L2_lambda, 
                           design_matrix=design_matrix_train, 
                           output_data_train=output_data_train)
print('w_closed =', np.round(w_closed.flatten(),3))

# Gradient descent solution
SGD_res = SGD_sol(learning_rate=learning_rate, 
                  minibatch_size=len(input_data_train), 
                  num_epochs=num_epochs, 
                  L2_lambda=L2_lambda, 
                  design_matrix_train=design_matrix_train,
                  design_matrix_eval=design_matrix_eval,
                  output_data_train=output_data_train,
                  output_data_eval=output_data_eval,
                  M=clusters_info[0])
w_SGD = SGD_res[0]
print('w_SGD =', np.round(w_SGD[-1,:,:].flatten(),3))


# early stop
stop_params = earlyStopping(max_epochs=num_epochs,
                            patience=10, 
                            n_epochs=5, 
                            params=SGD_res[0], 
                            this_validation_loss=SGD_res[2]) 

w_SGD_star = stop_params[0].flatten()
print('w_SGD_star =', np.round(stop_params[0].flatten(),3))

early_stop_epoch = stop_params[1]
print('early stop iteration number =', stop_params[1])

# model test
test_E = errorFrom(designMatrix=design_matrix_test,weights=w_SGD_star,targets=output_data_test)
print('test error =', np.round(test_E,2), '(', round((test_E/2)*100,2), '%',')')

