
# coding: utf-8

# In[221]:

import numpy as np
import matplotlib.pyplot as plt
from statistics import mean, stdev, variance
from numpy.linalg import inv
import math
from math import log10, floor

print("UBitName = amirbagh")
print("personNumber = 50135018")

def round_sig(x, sig=3):  # rounding to 3 significant digits
    size = int(math.sqrt(x.size))
    x_round = np.zeros(shape=(size,size))
    for i in range(0,size):
        for j in range(0,size):
            if size == 1:
                x_round = round(x, sig-int(floor(log10(abs(x))))-1)
            if size > 1:
                x_round[i,j] = round(x[i,j], sig-int(floor(log10(abs(x[i,j]))))-1)

    return x_round

# read data file

data_text = """
    5 57 400400 25064;
    4.6 58.6 512500 30228;
    4.5 54.5 550000 33513;
    4.3 55.9 440000 30698;
    4.3 55 628190 34722;
    4.2 53 437000 26660;
    4.1 54 416000 35580;
    4.1 55 603357 41811;
    4 55 376827 36180;
    4 52 459000 29720;
    3.7 55 202487 28804;
    3.6 59 363605 28813;
    3.6 52 482515 33624;
    3.4 54.5 571668 30452;
    3.4 54.5 392200 37635;
    3.4 52 610000 20876;
    3.4 58 485000 42184;
    3.3 54 851303 26537;
    3.3 55 526549 28591;
    3.3 57 400000 36774;
    3.3 53.5 315000 36624;
    3.1 58 644455 21550;
    3.1 48.5 425000 26356;
    3.1 53 475000 28379;
    3.1 53.5 389000 33151;
    3.1 49 358850 25267;
    3.1 61 496688 27444;
    3 54.5 566200 23312;
    3 51.5 464946 23551;
    3 50 525166 28591;
    2.9 56 544848 33241;
    2.9 54 580000 28168;
    2.8 53.5 520000 34980;
    2.8 54 188294 36286;
    2.8 53.5 310000 36276;
    2.7 59.8 411752 26030;
    2.6 50 448800 20816;
    2.6 59.5 643309 21550;
    2.6 51 493272 27409;
    2.6 45 403337 30888;
    2.5 49.9 499194 29960;
    2.5 46 485088 23540;
    2.4 47 332100 39360;
    2.4 48.7 421000 26077;
    2.4 50.5 423074 21642;
    2.4 51 341053 21388;
    2.4 49 394956 29696;
    2.4 53 518279 30378;
    2.4 51 662500 25510
"""
data = np.array(np.matrix(data_text))

mu = np.mean(data, axis=0)
var = np.var(data, axis=0)
sigma = np.std(data, axis=0)

# part 1
#get the values for a given column and set a variable for each value
score = data[:,0]
mu1 = round_sig(mu[0], sig=3)
var1 = round_sig(var[0], sig=3)
sigma1 = round_sig(sigma[0], sig=3)

overhead = data[:,1]
mu2 = round_sig(mu[1], sig=3)
var2 = round_sig(var[1], sig=3)
sigma2 = round_sig(sigma[1], sig=3)

adminpay = data[:,2]
mu3 = round_sig(mu[2], sig=3)
var3 = round_sig(var[2], sig=3)
sigma3 = round_sig(sigma[2], sig=3)

tuition = data[:,3]
mu4 = round_sig(mu[3], sig=3)
var4 = round_sig(var[3], sig=3)
sigma4 = round_sig(sigma[3], sig=3)

print("mu1 =", mu1)
print("mu2 =", mu2)
print("mu3 =", mu3)
print("mu4 =", mu4)

print("var1 =", var1)
print("var2 =", var2)
print("var3 =", var3)
print("var4 =", var4)

print("sigma1 =", sigma1)
print("sigma2 =", sigma2)
print("sigma3 =", sigma3)
print("sigma4 =", sigma4)

# part 2
# calculating covariance and correlation matrices
covarianceMat = round_sig(np.cov(data.T), sig=3)
correlationMat = round_sig(np.corrcoef(data.T), sig=3)

print("covarianceMat = ")
print(covarianceMat)

print("correlationMat = ")
print(correlationMat)

# plotting the correlation matrix
plt.matshow(correlationMat)

label = ['score', 'overhead', 'adminpay', 'tuition']
x_pos = np.arange(len(label))
plt.xticks(x_pos,label)

y_pos = np.arange(len(label))
plt.yticks(y_pos,label)

figure_title = 'Correlation between ranking criteria'
plt.text(1.5, -1.08, figure_title,
         horizontalalignment='center',
         fontsize=12)

plt.colorbar()
plt.show()

# part 3

mean = mu
cov = covarianceMat

llh_each_row = -((data-mu)/sigma)**2. / 2. - np.log((2.*math.pi)**0.5*sigma)
llh = np.sum(llh_each_row, axis=0)

print("logLikelihood = ",  round_sig(np.sum(llh), sig=3))

# part 4
# loglikelihood using Bayesian network

def BN_llh(children, parents):
    N = data.shape[0]
    all_ones = np.ones([N, 1])
    Phi = np.hstack([all_ones, data[:, parents]])
    Y = data[:, children]
    Phi_T = np.transpose(Phi)
    beta = np.linalg.solve(np.dot(Phi_T, Phi), np.dot(Phi_T, Y))
    sigma_square = np.mean([
        np.square(np.dot(np.transpose(beta), Phi[n, :]) - Y[n]) for n in range(N)
    ])
    llh = -N/2. * (np.log(2. * math.pi * sigma_square) + 1.)
    return beta, sigma_square, llh

# Binary graph showing the relation between variables (Bayesian network)
BNgraph = np.matrix([[0, 0, 0, 0],
                    [1, 0, 1, 0],
                    [0, 0, 0, 0],
                    [1, 1, 1, 0]])
print("BNgraph = ")
print(BNgraph)

# joint probabilities using Bayesian network
N = 49
# X = [CS Score, Research Overhead, Admin Base Pay, Tuition]
# p(adminpay|tuition,overhead)
BN_llh_1 = BN_llh([2], [3,1])[2]

# p(tuition)
BN_llh_2 = llh[3]

# p(overhead|tuition)
BN_llh_3 = BN_llh([1], [3])[2]

# p(score|tuition,overhead)
BN_llh_4 = BN_llh([0], [3,1])[2]

# log-likelihood from Bayesian network relations
BNlogLikelihood = round_sig(BN_llh_1 + BN_llh_2 + BN_llh_3 + BN_llh_4, sig=3)
print("BNlogLikelihood = ", BNlogLikelihood)


# In[ ]:




# In[ ]:




# In[ ]:



